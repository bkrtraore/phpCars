
<!--- VIEW --->
<style>
    #container-Error{
        width:100%;
        padding: 110px 0px;
        font-size: 20px;
        text-align: center;
    }

    #container-Error h2 {
        width: 50%;
        margin: auto;
        padding: 10px 20px;
        border: 1px solid #000;
    }
</style>
<div id="container-Error">
    <h2><?php echo $erreur?></h2>
</div>